using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;



public class GameManager : MonoBehaviour
{
    [SerializeField] TMP_Text countText;          // Displays the current count (e.g., pets or resources)
    [SerializeField] TMP_Text incomeText;         // Displays the current income per second
    [SerializeField] StoreUpgrade[] storeUpgrades; // An array of store upgrades that affect income
    [SerializeField] int updatesPerSecond = 5;    // How often the game will update its calculations (e.g., 5 times per second)

    [HideInInspector] public float count = 0;     // The current amount of resources or pets
    float nextTimeCheck = 1;                      // Tracks the next time to check and update the calculations
    float lastIncomeValue = 0;                    // The most recent calculated income per second

    private void Start()
    {
        // Initialize the UI by updating the displayed values
        UpdateUI();
    }

    // Update is called once per frame
    void Update()
    {
        // If it's time for the next update (based on updatesPerSecond), perform the idle calculation
        if (nextTimeCheck < Time.timeSinceLevelLoad)
        {
            IdleCalculate();  // Update the count and income based on the upgrades
            nextTimeCheck = Time.timeSinceLevelLoad + (1f / updatesPerSecond); // Set the next time check
        }
    }

    // IdleCalculate is called to update the resources and income per second from all store upgrades
    void IdleCalculate()
    {
        float sum = 0; // Initialize the sum of all upgrades' income per second

        // Loop through all store upgrades and sum their income per second
        foreach (var storeUpgrade in storeUpgrades)
        {
            sum += storeUpgrade.CalculateIncomePerSecond(); // Add the income per second from this upgrade
            storeUpgrade.UpdateUI(); // Update the UI for this upgrade
        }

        // Store the most recent calculated income per second
        lastIncomeValue = sum;

        // Increase the count (resources) based on the income value per second, adjusted for updates per second
        count += sum / updatesPerSecond;

        // Update the main UI with the new count and income values
        UpdateUI();
    }

    // ClickAction is triggered when the player clicks a button or performs an action that earns resources
    public void ClickAction()
    {
        count++; // Increment the count by 1 (for example, when a button is clicked)
        count += lastIncomeValue * 0.02f; // Add a bonus based on the most recent income (a small fraction)
        UpdateUI(); // Update the UI to reflect the new values
    }

    // PurchaseAction is used to try purchasing an upgrade by checking if the player can afford it
    public bool PurchaseAction(int cost)
    {
        // If the player has enough resources to purchase the upgrade
        if (count >= cost)
        {
            count -= cost; // Deduct the cost from the current resources
            UpdateUI(); // Update the UI to reflect the new count
            return true; // Return true to indicate the purchase was successful
        }

        return false; // Return false if the player cannot afford the purchase
    }

    // UpdateUI is used to update the count and income text on the UI
    void UpdateUI()
    {
        // Update the resource count text with the current count, rounded to an integer
        countText.text = Mathf.RoundToInt(count).ToString();

        // Update the income text to show the current income per second
        incomeText.text = lastIncomeValue.ToString() + "/s";
    }
}
