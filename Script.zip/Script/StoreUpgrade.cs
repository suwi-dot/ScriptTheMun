using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class StoreUpgrade : MonoBehaviour
{
    [Header("Components")]
    // The UI components that display price, income information, button, character image, and upgrade name
    public TMP_Text priceText;           // Displays the price of the upgrade
    public TMP_Text incomeInfoText;      // Displays the income generated per second
    public Button button;                // The button to purchase the upgrade
    public Image characterImage;         // The image of the character related to the upgrade
    public TMP_Text upgradeNameText;     // Displays the name of the upgrade

    [Header("Generator values")]
    // The properties of the upgrade itself
    public string upgradeName;           // Name of the upgrade
    public int startPrice = 15;          // Initial price of the upgrade
    public float upgradePriceMutiplier; // Price multiplier that increases with each level
    public float petPerUpgrade = 0.1f;  // Amount of pets generated per second per upgrade level

    [Header("Managers")]
    // Reference to the game manager that handles resources and game logic
    public GameManager gameManager;

    // The current level of the upgrade
    int level = 0;

    // Start is called before the first frame update
    private void Start()
    {
        // Update the UI to reflect the initial state of the upgrade
        UpdateUI();
    }

    // This method is triggered when the player clicks the upgrade button
    public void ClickAction()
    {
        // Calculate the price of the upgrade based on the current level
        int price = CalculatePrice();

        // Attempt to make the purchase through the game manager
        bool purchaseSuccess = gameManager.PurchaseAction(price);

        // If the purchase was successful, increment the level and update the UI
        if (purchaseSuccess)
        {
            level++;
            UpdateUI();
        }
    }

    // Update the UI elements to reflect the current state of the upgrade
    public void UpdateUI()
    {
        // Update the price text based on the calculated price for the current level
        priceText.text = CalculatePrice().ToString();

        // Update the income information text (shows level x pet generation rate)
        incomeInfoText.text = level.ToString() + " x " + petPerUpgrade + "/s";

        // Check if the player can afford the upgrade and enable/disable the button accordingly
        bool canAfford = gameManager.count >= CalculatePrice();
        button.interactable = canAfford;

        // If the upgrade has been purchased (level > 0), set the character image to its original color
        // Otherwise, make it black (indicating it hasn't been purchased)
        bool isPurchased = level > 0;
        characterImage.color = isPurchased ? Color.white : Color.black;

        // If the upgrade has been purchased, show its name; otherwise, show "????"
        upgradeNameText.text = isPurchased ? upgradeName : "????";
    }

    // Calculate the price of the upgrade based on the starting price and the upgrade price multiplier
    int CalculatePrice()
    {
        // The price increases exponentially with each level using the multiplier
        int price = Mathf.RoundToInt(startPrice * Mathf.Pow(upgradePriceMutiplier, level));
        return price;
    }

    // Calculate the income generated per second based on the level of the upgrade
    public float CalculateIncomePerSecond()
    {
        return petPerUpgrade * level;
    }
}
